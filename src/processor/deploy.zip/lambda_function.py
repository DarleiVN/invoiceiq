import json
import boto3
import os
import urllib.parse
from datetime import datetime

textract = boto3.client('textract')
dynamodb = boto3.resource('dynamodb')

TABLE_NAME = os.environ.get('TABLE_NAME', 'invoiceiq-dados-extraidos')
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    print("INICIANDO PROCESSAMENTO NUCLEAR - V4 (PROMPT ENGINEERING)...")
    for sqs_record in event['Records']:
        try:
            s3_event = json.loads(sqs_record['body'])
            if 'Event' in s3_event and s3_event['Event'] == 's3:TestEvent': continue
                
            for s3_record in s3_event['Records']:
                bucket_name = s3_record['s3']['bucket']['name']
                object_key = urllib.parse.unquote_plus(s3_record['s3']['object']['key'])
                
                print(f"Enviando para o Textract: {object_key}")
                response = textract.analyze_document(
                    Document={'S3Object': {'Bucket': bucket_name, 'Name': object_key}},
                    FeatureTypes=['QUERIES'],
                    QueriesConfig={
                        'Queries': [
                            # A PERGUNTA MÁGICA:
                            {'Text': 'Qual o nome do Prestador de Servicos?', 'Alias': 'VENDOR'},
                            {'Text': 'Qual o valor liquido ou total?', 'Alias': 'TOTAL'}
                        ]
                    }
                )
                
                extracted_data = {}
                blocks_map = {block['Id']: block for block in response.get('Blocks', [])}
                for block in response.get('Blocks', []):
                    if block['BlockType'] == 'QUERY':
                        alias = block['Query']['Alias']
                        if 'Relationships' in block:
                            for rel in block['Relationships']:
                                if rel['Type'] == 'ANSWER':
                                    answer_id = rel['Ids'][0]
                                    extracted_data[alias] = blocks_map[answer_id]['Text']
                
                item = {
                    'document_id': object_key,
                    'process_date': datetime.utcnow().isoformat(),
                    'vendor_name': extracted_data.get('VENDOR', 'Fornecedor Nao Encontrado'),
                    'total_amount': extracted_data.get('TOTAL', '0,00'),
                    'status': 'PROCESSED_BY_AI_QUERIES'
                }
                table.put_item(Item=item)
                print("Extracao Concluida com Sucesso!")
        except Exception as e:
            print(f"Erro fatal: {str(e)}")
            raise e
    return {'statusCode': 200, 'body': 'OK'}
