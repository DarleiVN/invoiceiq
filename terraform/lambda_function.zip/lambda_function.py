import json, urllib.parse, boto3, os, datetime

textract = boto3.client('textract')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table(os.environ.get('TABLE_NAME', 'invoiceiq-dados-extraidos'))

def lambda_handler(event, context):
    for record in event.get('Records', []):
        try:
            body = json.loads(record['body'])
            s3_event = body['Records'][0]
            bucket = s3_event['s3']['bucket']['name']
            key = urllib.parse.unquote_plus(s3_event['s3']['object']['key'])

            # MUDANÇA: Usaremos ANALYZE_DOCUMENT com FORMS, não QUERIES.
            # Isso é muito mais resiliente para recibos variados.
            response = textract.analyze_document(
                Document={'S3Object': {'Bucket': bucket, 'Name': key}},
                FeatureTypes=['FORMS']
            )

            # Extração de texto plano de forma simples
            all_text = ""
            for block in response['Blocks']:
                if block['BlockType'] == 'LINE':
                    all_text += block['Text'] + "\n"

            # Fallback de processamento (Busca termos chave)
            vendor = "NÃO ENCONTRADO"
            amount = "0,00"
            
            lines = all_text.split('\n')
            for i, line in enumerate(lines):
                # Procura padrões comuns de fornecedores
                if any(x in line.upper() for x in ['FORNECEDOR', 'NOME', 'RAZAO']):
                    if len(line) > 15: vendor = line.split(':')[-1].strip()
                # Procura padrões de valores
                if 'R$' in line:
                    amount = line.split('R$')[-1].strip()

            table.put_item(Item={
                'document_id': key,
                'vendor_name': vendor[:30].upper(),
                'total_amount': amount,
                'process_date': datetime.datetime.now().isoformat(),
                'status': 'PROCESSED_BY_FORMS'
            })
            print(f"Sucesso com Forms: {vendor}")

        except Exception as e:
            print(f"Erro: {str(e)}")
            raise e
