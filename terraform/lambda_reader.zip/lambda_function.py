import json
import boto3
import os

# Inicializa o recurso do DynamoDB
dynamodb = boto3.resource('dynamodb')

# Tabela injetada de forma dinâmica pelo Terraform
TABLE_NAME = os.environ.get('TABLE_NAME', 'invoiceiq-dados-extraidos')
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    print("A iniciar a leitura dos dados do DynamoDB...")
    try:
        # Executa o Scan para obter todas as faturas processadas
        response = table.scan()
        items = response.get('Items', [])
        
        # IMPORTANTE: Cabeçalhos CORS para permitir que o browser do cliente aceda à API
        headers = {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",  # Em produção, limitaríamos ao domínio do CloudFront
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "GET,OPTIONS"
        }
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(items)
        }
        
    except Exception as e:
        print(f"Erro ao ler os dados da tabela: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                "Access-Control-Allow-Origin": "*"
            },
            'body': json.dumps({'error': 'Erro interno ao aceder à base de dados'})
        }
