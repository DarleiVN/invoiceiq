import json
import boto3
import os

s3_client = boto3.client('s3')
BUCKET_NAME = os.environ.get('BUCKET_NAME', 'invoiceiq-entrada-vieiraniz')

def lambda_handler(event, context):
    try:
        # Pega o nome do documento que o frontend enviou na URL
        query_params = event.get('queryStringParameters') or {}
        document_id = query_params.get('document_id')
        
        if not document_id:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Parâmetro document_id ausente'})
            }

        # Gera o Link Pré-assinado válido por apenas 60 segundos
        url = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': BUCKET_NAME, 'Key': document_id},
            ExpiresIn=60
        )

        # Devolve o link com headers de CORS liberados para o navegador
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, OPTIONS'
            },
            'body': json.dumps({'url': url})
        }
    except Exception as e:
        print(f"Erro ao gerar URL: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'Erro interno do servidor'})
        }
